import heapq

def add_routers(network_topology, r1, r2, dist):
    if r1 not in network_topology:
        network_topology[r1] = []
    if r2 not in network_topology:
        network_topology[r2] = []
    network_topology[r1].append((r2, dist))
    network_topology[r2].append((r1, dist))

class Router:
    def __init__(self, router_id, ip_address):
        self.router_id = router_id
        self.ip_address = ip_address
        self.adjacent_routers = {}
        self.sequence_number = 0

    def add_adjacent_router(self, router, cost):
        self.adjacent_routers[router] = cost

    def dijkstra_shortest_path(self):
        visited = {self.router_id: 0}
        hq = [(0, self.router_id)]
        while hq:
            current_distance, current_router = heapq.heappop(hq)
            for adjacent_router, cost in self.adjacent_routers.items():
                new_distance = current_distance + cost
                if adjacent_router not in visited or new_distance < visited[adjacent_router]:
                    visited[adjacent_router] = new_distance
                    heapq.heappush(hq, (new_distance, adjacent_router))
        return visited

    def send_hello(self):
        print(f"Sending Hello from router {self.router_id} with IP address {self.ip_address}")

    def send_lsa(self):
        self.sequence_number += 1
        lsa = LSA(self.router_id, self.ip_address, self.sequence_number)
        print(f"Sending LSA from router {self.router_id} with IP address {self.ip_address}:")
        print(f"  Router ID: {lsa.router_id}")
        print(f"  Sequence Number: {lsa.sequence_number}")
        print(f"  Link State ID (Originating Router's IP): {self.ip_address}")

    def send_lsr(self, requested_router_id):
        print(f"Sending LSR from router {self.router_id} with IP address {self.ip_address} to request LSA of router {requested_router_id}")

    def send_lsu(self, lsas):
        print(f"Sending LSU from router {self.router_id} with IP address {self.ip_address} with the following LSAs:")
        for l in lsas:
            print(f"  Router ID: {l.router_id}")
            print(f"  Sequence Number: {l.sequence_number}")
            print(f"  Link State ID (Originating Router's IP): {self.ip_address}")

class LSA:
    def __init__(self, router_id, link_state_id, sequence_number):
        self.router_id = router_id
        self.link_state_id = link_state_id
        self.sequence_number = sequence_number

# Hardcoded network topology
network_topology = {}
add_routers(network_topology, 'A', 'B', 2)
add_routers(network_topology, 'C', 'B', 4)
add_routers(network_topology, 'E', 'B', 3)
add_routers(network_topology, 'C', 'D', 3)
add_routers(network_topology, 'D', 'E', 5)

# Create Router instances for each router in the network topology
routers = {router_id: Router(router_id, f"192.168.0.{i+1}") for i, router_id in enumerate(network_topology)}

# Add adjacent routers to each Router instance
for router_id, router in routers.items():
    for neighbor, cost in network_topology[router_id]:
        router.add_adjacent_router(neighbor, cost)

# Print initial routing tables
print("Initial Routing Tables:")
for router_id, router in routers.items():
    print(f"Router {router_id}:")
    for neighbor, cost in router.adjacent_routers.items():
        print(f"  {neighbor} -> Cost: {cost}")

# Send Hello, LSA, LSR, LSU messages
for router_id, router in routers.items():
    router.send_hello()
    router.send_lsa()
    print("")

# Perform Dijkstra's algorithm and print shortest paths
print("\nShortest Paths:")
for router_id, router in routers.items():
    shortest_paths = router.dijkstra_shortest_path()
    print(f"Shortest paths from {router_id}: {shortest_paths}")

